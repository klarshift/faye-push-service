package com.klarshift.grails.plugins.pushservice

class FayeEndpointController {

    def scaffold = FayeEndpoint
}
