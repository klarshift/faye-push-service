package com.klarshift.grails.plugins.pushservice

class FayeChannelController {

     def scaffold = FayeChannel
}
